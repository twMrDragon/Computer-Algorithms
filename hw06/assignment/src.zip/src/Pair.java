public class Pair<E> {

	public E first, second;

	Pair(E first, E second) {
		this.first = first;
		this.second = second;
	}

}
