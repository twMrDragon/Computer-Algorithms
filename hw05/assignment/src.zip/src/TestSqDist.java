
public class TestSqDist {

	public static void main(String[] args) {

	}

}
